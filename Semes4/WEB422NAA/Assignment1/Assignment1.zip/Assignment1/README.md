/*********************************************************************************
* WEB422 – Assignment 1
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Name: Long Nguyen  Student ID: 155176183   Date: May 25th, 2021
* Heroku Link: https://web422-assignment-lnguyen97.herokuapp.com/
*
********************************************************************************/
