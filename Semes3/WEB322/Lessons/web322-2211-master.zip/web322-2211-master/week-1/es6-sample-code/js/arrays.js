
const movies = [ "The Matrix", "Avengers:Infinity Wars", "Titanic" ];

export default movies;