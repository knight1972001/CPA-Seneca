var cake=[{
    img: '/images/topContent/mousecake.jpg',
    title: 'Strawberry GreenTea Mousse Cake',
    des: 'With a special combination of strawberry and green tea, the cake will give you a special flavor',
    price: '$12'
},
{
    img: '/images/topContent/tartcake.jpg',
    title: 'Gluten Free Lemon (Sliced)',
    des: 'With an easy press-in almond shortbread crust and luscious, tangy lemon curd, this French-style gluten-free lemon tart is an easier version of the classic. This is the same recipe as my gluten-free lemon bars, just in a different shape!',
    price: '$15'
},
{
    img: '/images/topContent/chessecake.jpg',
    title: 'Oreo Cheese Cake (Sliced)',
    des: 'This Oreo Cheesecake is thick, creamy and filled with cookies and cream! It’s baked in an Oreo crust and topped with white chocolate ganache and homemade whipped cream! With the amount of Oreos baked into it, this is the BEST Oreo Cheesecake you’ll ever have!',
    price: '$12'
}]

var pizza=[{
    img: '/images/topContent/hamPizza.jpg',
    title: 'Spanish Chorizo and Serrano Ham Pizza',
    des: 'If you believe pizza was made for meat and meat alone, this new pizza is for you!  Made using our fermented Turkish dough to give it a crispy crust and delicious flavour, we add tomato sauce, chorizo, ham and aged white cheddar.',
    price: '$6 per piece'
},{
    img: '/images/topContent/hawaiiPizza.jpg',
    title: 'Hawaiian Pizza',
    des: 'The perfect on-the-go size, enjoy this classic tropical pizza made with tomato sauce, ham, pineapple and topped with aged white cheddar.  Our Pizzas are made using our fermented Turkish dough, making the crust flavourful and the just the right amount of crispy.',
    price: '$6 per piece'
},{
    img: '/images/topContent/threeCheese.jpg',
    title: 'Three-Cheese Veggie Pizza',
    des: 'This pizza is perfect for those who don\'t want pizza with too much meat. We add tomato sauce, aged white cheddar, red peppers, mushrooms and olives for the classic vegetarian pizza.',
    price: '$6 per piece'
}]